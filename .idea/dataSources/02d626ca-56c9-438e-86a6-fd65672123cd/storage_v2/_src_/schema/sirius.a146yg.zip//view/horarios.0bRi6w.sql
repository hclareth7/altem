CREATE VIEW horarios AS
  SELECT
    `sirius`.`datos_academicos`.`ID_DOCENTE`                            AS `id`,
    `sirius`.`datos_academicos`.`NOMBRES_DOCENTE`                       AS `NOMBRES_DOCENTE`,
    `sirius`.`datos_academicos`.`APELLIDOS_DOCENTE`                     AS `APELLIDOS_DOCENTE`,
    `sirius`.`datos_academicos`.`ASIGNATURA`                            AS `ASIGNATURA`,
    `sirius`.`datos_academicos`.`NRC`                                   AS `NRC`,
    `sirius`.`datos_academicos`.`TIPO`                                  AS `TIPO`,
    max(replace(`sirius`.`datos_academicos`.`Lunes`, 'null', NULL))     AS `LUNES`,
    max(replace(`sirius`.`datos_academicos`.`Martes`, 'null', NULL))    AS `MARTES`,
    max(replace(`sirius`.`datos_academicos`.`Miercoles`, 'null', NULL)) AS `MIERCOLES`,
    max(replace(`sirius`.`datos_academicos`.`Jueves`, 'null', NULL))    AS `JUEVES`,
    max(replace(`sirius`.`datos_academicos`.`Viernes`, 'null', NULL))   AS `VIERNES`,
    max(replace(`sirius`.`datos_academicos`.`Sabado`, 'null', NULL))    AS `SABADO`,
    max(replace(`sirius`.`datos_academicos`.`Domingo`, 'null', NULL))   AS `DOMINGO`
  FROM `sirius`.`datos_academicos`
  GROUP BY `sirius`.`datos_academicos`.`ID_DOCENTE`, `sirius`.`datos_academicos`.`NOMBRES_DOCENTE`,
    `sirius`.`datos_academicos`.`APELLIDOS_DOCENTE`, `sirius`.`datos_academicos`.`ASIGNATURA`,
    `sirius`.`datos_academicos`.`NRC`, `sirius`.`datos_academicos`.`TIPO`;

