CREATE VIEW asistentes AS
  SELECT DISTINCT
    `sirius`.`datos_academicos`.`NRC`               AS `id`,
    `sirius`.`datos_academicos`.`ASIGNATURA`        AS `ASIGNATURA`,
    `sirius`.`datos_academicos`.`ID_DOCENTE`        AS `ID_DOCENTE`,
    `sirius`.`datos_academicos`.`NOMBRES_DOCENTE`   AS `NOMBRES_DOCENTE`,
    `sirius`.`datos_academicos`.`APELLIDOS_DOCENTE` AS `APELLIDOS_DOCENTE`,
    `sirius`.`estudiantes`.`ID`                     AS `ID_ESTUDIANTE`,
    `sirius`.`estudiantes`.`NOMBRES`                AS `NOMBRE_ESTUDIANTE`,
    `sirius`.`estudiantes`.`APELLIDOS`              AS `APELLIDOS_ESTUDIANTE`,
    `sirius`.`estudiantes`.`PROGRAMA`               AS `PROGRAMA`
  FROM (`sirius`.`estudiantes`
    JOIN `sirius`.`datos_academicos` ON ((`sirius`.`datos_academicos`.`ID` = `sirius`.`estudiantes`.`ID`)));

