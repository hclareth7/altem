CREATE PROCEDURE sirius_datos_academicos_sp(IN ID                VARCHAR(45), IN FECHA VARCHAR(45),
                                            IN NRO_COMPONENTES   VARCHAR(45), IN NOMBRES_DOCENTE VARCHAR(45),
                                            IN APELLIDOS_DOCENTE VARCHAR(45), IN ID_DOCENTE VARCHAR(45),
                                            IN NOTA_PARCIAL      VARCHAR(45), IN TIPO_DE_CAPTURA VARCHAR(45),
                                            IN COD_COMPONENTE    VARCHAR(45), IN COD_ESTATUS VARCHAR(45),
                                            IN Hrs_Sem           INT, IN TIPO VARCHAR(45), IN Domingo VARCHAR(45),
                                            IN Sabado            VARCHAR(45), IN Viernes VARCHAR(45),
                                            IN Jueves            VARCHAR(45), IN Miercoles VARCHAR(45),
                                            IN Martes            VARCHAR(45), IN Lunes VARCHAR(45),
                                            IN SESION            VARCHAR(45), IN ASIGNATURA VARCHAR(45),
                                            IN CURSO             VARCHAR(45), IN MATERIA VARCHAR(45),
                                            IN NRC               VARCHAR(45), IN PERIODO VARCHAR(45),
                                            IN PROMEDIO_PERIODO  VARCHAR(45), IN PGA_ACOMULADO VARCHAR(45))
  BEGIN
START TRANSACTION;
  -- ADD option 5
INSERT INTO datos_academicos
(
 ID ,
 FECHA ,
 NRO_COMPONENTES ,
 NOMBRES_DOCENTE ,
 APELLIDOS_DOCENTE ,
 ID_DOCENTE ,
 NOTA_PARCIAL ,
 TIPO_DE_CAPTURA ,
 COD_COMPONENTE ,
 COD_ESTATUS ,
 Hrs_Sem ,
 TIPO ,
 Domingo ,
 Sabado ,
 Viernes ,
 Jueves ,
 Miercoles ,
 Martes ,
 Lunes ,
 SESION ,
 ASIGNATURA ,
 CURSO ,
 MATERIA ,
 NRC ,
 PERIODO ,
 PROMEDIO_PERIODO ,
 PGA_ACOMULADO 
)
 VALUES(
 ID ,
 FECHA ,
 NRO_COMPONENTES ,
 NOMBRES_DOCENTE ,
 APELLIDOS_DOCENTE ,
 ID_DOCENTE ,
 NOTA_PARCIAL ,
 TIPO_DE_CAPTURA ,
 COD_COMPONENTE ,
 COD_ESTATUS ,
 Hrs_Sem ,
 TIPO ,
 Domingo ,
 Sabado ,
 Viernes ,
 Jueves ,
 Miercoles ,
 Martes ,
 Lunes ,
 SESION ,
 ASIGNATURA ,
 CURSO ,
 MATERIA ,
 NRC ,
 PERIODO ,
 PROMEDIO_PERIODO ,
 PGA_ACOMULADO 
);
-- SET poid = (SELECT LAST_INSERT_ID());

COMMIT;
END;

