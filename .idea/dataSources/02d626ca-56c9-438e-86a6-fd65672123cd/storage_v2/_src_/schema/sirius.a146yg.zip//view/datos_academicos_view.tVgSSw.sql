CREATE VIEW datos_academicos_view AS
  SELECT
    `sirius`.`datos_academicos`.`ID`                AS `ID`,
    `sirius`.`datos_academicos`.`FECHA`             AS `FECHA`,
    `sirius`.`datos_academicos`.`NRO_COMPONENTES`   AS `NRO_COMPONENTES`,
    `sirius`.`datos_academicos`.`NOMBRES_DOCENTE`   AS `NOMBRES_DOCENTE`,
    `sirius`.`datos_academicos`.`APELLIDOS_DOCENTE` AS `APELLIDOS_DOCENTE`,
    `sirius`.`datos_academicos`.`ID_DOCENTE`        AS `ID_DOCENTE`,
    `sirius`.`datos_academicos`.`NOTA_PARCIAL`      AS `NOTA_PARCIAL`,
    `sirius`.`datos_academicos`.`TIPO_DE_CAPTURA`   AS `TIPO_DE_CAPTURA`,
    `sirius`.`datos_academicos`.`COD_COMPONENTE`    AS `COD_COMPONENTE`,
    `sirius`.`datos_academicos`.`COD_ESTATUS`       AS `COD_ESTATUS`,
    `sirius`.`datos_academicos`.`Hrs_Sem`           AS `Hrs_Sem`,
    `sirius`.`datos_academicos`.`TIPO`              AS `TIPO`,
    `sirius`.`datos_academicos`.`Domingo`           AS `Domingo`,
    `sirius`.`datos_academicos`.`Sabado`            AS `Sabado`,
    `sirius`.`datos_academicos`.`Viernes`           AS `Viernes`,
    `sirius`.`datos_academicos`.`Jueves`            AS `Jueves`,
    `sirius`.`datos_academicos`.`Miercoles`         AS `Miercoles`,
    `sirius`.`datos_academicos`.`Martes`            AS `Martes`,
    `sirius`.`datos_academicos`.`Lunes`             AS `Lunes`,
    `sirius`.`datos_academicos`.`SESION`            AS `SESION`,
    `sirius`.`datos_academicos`.`ASIGNATURA`        AS `ASIGNATURA`,
    `sirius`.`datos_academicos`.`CURSO`             AS `CURSO`,
    `sirius`.`datos_academicos`.`MATERIA`           AS `MATERIA`,
    `sirius`.`datos_academicos`.`NRC`               AS `NRC`,
    `sirius`.`datos_academicos`.`PERIODO`           AS `PERIODO`,
    `sirius`.`datos_academicos`.`PROMEDIO_PERIODO`  AS `PROMEDIO_PERIODO`,
    `sirius`.`datos_academicos`.`PGA_ACOMULADO`     AS `PGA_ACOMULADO`
  FROM `sirius`.`datos_academicos`
  GROUP BY `sirius`.`datos_academicos`.`ID`;

