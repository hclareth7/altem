CREATE VIEW docentes AS
  SELECT DISTINCT
    `sirius`.`datos_academicos`.`ID_DOCENTE`        AS `codigo`,
    `sirius`.`datos_academicos`.`NOMBRES_DOCENTE`   AS `nombres`,
    `sirius`.`datos_academicos`.`APELLIDOS_DOCENTE` AS `apellidos`
  FROM `sirius`.`datos_academicos`;

